<?php
/* Route.php
 * This is the class for the Route object.
 */

require_once 'Airport.php';
require_once 'Vehicle.php';
require_once 'Crew.php';

class Route 
{
  private $crew_members = []; 
  private Vehicle $vehicle;
  private Airport $airport;
  private DateTime $tempo;

  
  public function __construct(array $crew_members,
                              Airport $airport,
                              Vehicle $vehicle)
  {
    $this->crew_members = $crew_members;
    $this->airport = $airport;
    $this->vehicle = $vehicle;
  }


  private function calculaDistancia() : float
  {
    $distancia;
    //calcula distancia (em km)
    return $distancia;  
  }

  private function calculaTempo() : float
  {
    //tempo = distancia/velocidade -- velocidade padrão de 18km/h
    $this->tempo = $this->calculaDistancia() / 18.0;
    return $this->tempo;  //em horas
  }

 // Setters and Getters
  public function getVehicle() : Vehicle
  {
    return $this->vehicle;
  }
    
  public function getAirport() : Airport
  {
    return $this->airport;
  }
  
  public function getTempo() : float
  {
    return $this->tempo;
  }
  
  public function getDistancia() : float
  {
    return $this->calculaDistancia();
  }
  
  public function setAirport(Airport $airport) : void
  {
    $this->airport = $airport;
  }
    
  public function setVehicle(Vehicle $vehicle) : void
  {
    $this->vehicle = $vehicle;
  }
  
  public function setCrew_members(array $crew_members) : void
  {
    $this->crew_members = $crew_members;
  }

  
  // Destructor
  public function __destruct()
  {
     echo "Route has been deleted.";
  }
}