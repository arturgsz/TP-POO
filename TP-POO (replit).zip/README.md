# TP-POO 2023/1
TP POO - Airport

[**Organização no Trello**](https://trello.com/b/Ri7DyeY9)

Sprint | UML | Código 
:------------ | :-------------| :-------------
Sprint 1 |  [x]  |   [x]   
Sprint 2 |  [x]  |   [x]  
Sprint 3 |  [x]  |   [x]   
Sprint 4 |  [x]  |   [ ]   
Sprint 5 |  [ ]  |   [ ]   
Sprint 6 |  [ ]  |   [ ]  
Sprint 7 |  [ ]  |   [ ]  


![title](img/Airport.jpeg)
