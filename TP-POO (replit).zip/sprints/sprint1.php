<?php
require_once("./src/FlightCompany.php");
require_once("./src/Airplane.php");
require_once("./src/Airport.php");
require_once("./src/Travel.php");
require_once("./src/FlightLines.php");

$Latam = new FlightCompany('LATAM','JJ','Tam Linhas Aéreas S/a - Processos','12.345.678/0001-12','LT', 34.2);
var_dump($Latam);
echo "<br>";

$Boeing_A320_PRGUO = new Airplane($flightCompanyLatam,'Boeing','A-320', 'PR-GUO', 2, 2.5);

var_dump($Boeing_A320_PRGUO);
echo "<br>";



